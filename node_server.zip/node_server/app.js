var express = require('express');
var socket = require('socket.io');

//App setup

var app = express();//creating server app 
var server = app.listen(4000,function(){
    console.log("4000 listening enabled");//starting to listening port 4000 you can edit this port as you like
});

//App user file

//socket setup
var io = socket(server);

io.on('connection',function(socket){
    console.log('user connected ',socket.id); //if user connected console will display it

    socket.on('chat',function(data){
        io.sockets.emit('chat',data); //receiving chat data and send to clients 
        console.log(socket.id+ " "+ data.message);//show message with message senders socket id in console
    });
});
