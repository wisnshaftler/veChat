$(document).on("pagecreate","#page1",function() {
    //The on() method attaches the event handlers
    //The id #page1 refers to id of the page to specify event
    var socket =io.connect('http://localhost:4000');//your server ip address and port number      
    function scroll(){ 
      $('#msg-show').animate({
         scrollTop: $('#msg-show').get(0).scrollHeight //auto scroll
      }, 100);
   }
   //msg sending and focus to message typing area
   $('#send').click(function(){
      var msg = $('#msg').val(); 
      var name = $('#name').val();
      $('#msg').val('');
      socket.emit('chat',{
         message:name + " : " +msg
      });
      $("#msg").focus();
   });
	//run on mobile device this code can send click event to send button when keybord enter is press
   $('#send').submit(function(){
      $('#send').click();
   });
   //this command check enter key in browser or emulators
   $('#msg').keydown(function(keyvalue){
         if (keyvalue.which == 13){
            $('#send').click();
         }
      });
	  //this command receive incoming data form server
   socket.on('chat',function(data){
      $('#msg-show').append(data.message+"<br><br>" );
      scroll();
   });
 });